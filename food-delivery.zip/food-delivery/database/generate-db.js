const fs = require('fs');
const path = require('path');

// Полные данные меню с исправленными путями к изображениям
const menuItems = [
  {
    id: 1,
    name: "Пицца Маргарита",
    description: "Классическая пицца с томатным соусом, моцареллой и базиликом",
    price: 450,
    category: "pizza",
    image: "/images/margherita.jpg"  // Добавлен ведущий слеш
  },
  {
    id: 2,
    name: "Пицца Пепперони",
    description: "Пицца с томатным соусом, моцареллой и острой колбаской пепперони",
    price: 550,
    category: "pizza",
    image: "/images/pepperoni.jpg"   // Добавлен ведущий слеш
  },
  {
    id: 3,
    name: "Пицца 4 Сыра",
    description: "Пицца с соусом альфредо и смесью сыров: моцарелла, горгонзола, пармезан, фета",
    price: 600,
    category: "pizza",
    image: "/images/four-cheese.jpg" // Добавлен ведущий слеш
  },
  {
    id: 4,
    name: "Чизбургер",
    description: "Аппетитный бургер с говяжьей котлетой, сыром, луком и соусом",
    price: 250,
    category: "burger",
    image: "/images/cheeseburger.jpg" // Добавлен ведущий слеш
  },
  {
    id: 5,
    name: "Бургер с беконом",
    description: "Бургер с говяжьей котлетой, беконом, сыром и соусом барбекю",
    price: 350,
    category: "burger",
    image: "/images/bacon-burger.jpg" // Добавлен ведущий слеш
  },
  {
    id: 6,
    name: "Чикенбургер",
    description: "Бургер с куриной котлетой, листьями салата и медово-горчичным соусом",
    price: 300,
    category: "burger",
    image: "/images/chicken-burger.jpg" // Добавлен ведущий слеш
  },
  {
    id: 7,
    name: "Греческий салат",
    description: "Свежие овощи, оливки, сыр фета и оливковое масло",
    price: 300,
    category: "salad",
    image: "/images/greek-salad.jpg" // Добавлен ведущий слеш
  },
  {
    id: 8,
    name: "Цезарь",
    description: "Курица, листья салата, сухарики и соус цезарь",
    price: 350,
    category: "salad",
    image: "/images/caesar.jpg" // Добавлен ведущий слеш
  },
  {
    id: 9,
    name: "Овощной салат",
    description: "Свежие сезонные овощи с оливковым маслом и лимонным соком",
    price: 250,
    category: "salad",
    image: "/images/vegetable-salad.jpg" // Исправлено на единый формат
  },
  {
    id: 10,
    name: "Кола",
    description: "Газированный напиток",
    price: 100,
    category: "drink",
    image: "/images/cola.jpg" // Добавлен ведущий слеш
  },
  {
    id: 11,
    name: "Лимонад",
    description: "Освежающий домашний лимонад",
    price: 150,
    category: "drink",
    image: "/images/lemonade.jpg" // Добавлен ведущий слеш
  },
  {
    id: 12,
    name: "Морс",
    description: "Ягодный морс из смородины и малины",
    price: 120,
    category: "drink",
    image: "/images/fruit-drink.jpg" // Добавлен ведущий слеш
  }
];

try {
  // Создаем папку database, если её нет
  if (!fs.existsSync('database')) {
    fs.mkdirSync('database');
    console.log("📂 Папка database создана");
  }

  // Сохраняем данные в JSON-файл
  fs.writeFileSync(
    path.join(__dirname, 'database', 'menu.json'), // Теперь файл сохраняется в папку database
    JSON.stringify(menuItems, null, 2),
    'utf8'
  );
  
  console.log("✅ База данных успешно создана в database/menu.json");
  console.log(`🛒 Загружено ${menuItems.length} позиций меню`);
  console.log("🍕 Пиццы:", menuItems.filter(item => item.category === "pizza").length);
  console.log("🍔 Бургеры:", menuItems.filter(item => item.category === "burger").length);
  console.log("🥗 Салаты:", menuItems.filter(item => item.category === "salad").length);
  console.log("🥤 Напитки:", menuItems.filter(item => item.category === "drink").length);

} catch (err) {
  console.error("❌ Ошибка при создании базы данных:", err.message);
  process.exit(1);
}